<html>
	<body>
		<form action="Registra.php" method="POST">
		<input name="username" type="text" placeholder="Inserisci l'username"></input><br>
		<input name="password" type="text" placeholder="Inserisci la password"></input><br>
		<input name="confPass" type="text" placeholder="Conferma la password"></input><br>
		<input  type="submit" value="Reigstra"></input>
		</form>
		<?php
			if($_SERVER["REQUEST_METHOD"]=="POST"){
				if(isset($_POST["username"]) && isset($_POST["password"]) && isset($_POST["confPass"])){
					if(!empty($_POST["username"]) && !empty($_POST["password"]) && !empty($_POST["confPass"]) ){
						$username=$_POST["username"];
						$pass=$_POST["password"];
						$confPass=$_POST["confPass"];
						if($pass!=$confPass){
							echo '<script language="javascript">';
										echo 'alert("Le password non corrispondono")';
										echo '</script>';
										die("");
						}else{

							
							//effettuo la connessione col DB
							include "connessione.php";   //include il codice php per la connessione dentro il codice
							//creo la query
							$sql="Insert into utente(username,password,ora,data)
								values('$username','$pass','time()','date()')";
										if ($conn->query($sql) === TRUE) {
											//echo "Dati Inseriti";
													echo '<script language="javascript">';
												echo 'alert("Registrato correttamente")';
												echo '</script>';
												header('Location: index.php');
												die("");
											
										} else {
											die( "Errore nella query: " . $conn->error);
										}
										
								$conn->close();
								
									}
					}else{
						echo '<script language="javascript">';
										echo 'alert("Uno o più dati non inseriti")';
										echo '</script>';
										die("");
					}
				}
			}
						
		?>
	</body>
</body>