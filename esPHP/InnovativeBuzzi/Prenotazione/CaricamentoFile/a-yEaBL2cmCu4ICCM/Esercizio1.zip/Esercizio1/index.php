<html>
	<title>Login </title>
	<body>
			
		<?php
		
			session_start();
				
			if(isset($_SESSION["username"]) && isset($_SESSION["password"])) {
				$username=$_SESSION["username"];
				$password=$_SESSION["password"];
				
			}else{
				$username="";
				$password="";	
			}
			$msg="";
					$msg="<form action=\"index.php\" method=\"POST\">
							<input name=\"username\" type=\"text\" placeholder=\"Inserisci il nome\" value=$username ></input><br>
							<input name=\"password\" type=\"password\" placeholder=\"Inserisci la password\" value=$password> </input><br>
							<input  type=\"checkbox\" name=\"ricordami\" value=\"ricorda\" >Ricordami</input><br>
							<input  type=\"submit\" value=\"Accedi\" ></input><br>
							<a href=\"Registra.php\" > Non sei registrato ? registrati</a> 
						</form>	";
						
				echo $msg;
					if($_SERVER["REQUEST_METHOD"]=="POST"){
						$username=$_POST["username"];
						$password=$_POST["password"];
						
						
						if(!isset($_POST["ricordami"])){
							$ricordami="non ricordarmi";
						}else{
							$ricordami="ricorda";
						}
						if(isset($username) && isset($password)){
							if(empty($userName) && empty($password)){
								
										echo '<script language="javascript">';
										echo 'alert("Uno o più dati non inseriti")';
										echo '</script>';
										die("");
							}else{
									///////controllo dal database se esiste////////////////////////
								//	$md5Pass=md5($password);
								//echo $username;
											include "connessione.php";
											$sql = "SELECT id from utente where username=\"$username\" && password=\"$password\" ";
											$records=$conn->query($sql);
											if ( $records == TRUE) {
													//echo "<br>Query eseguita!";
											} else {
												die("Errore nella query: " . $conn->error);
											}
															
											//gestisco gli eventuali dati estratti dalla query				
											if($records->num_rows ==0){
												echo '<script language="javascript">';
												echo 'alert("Username o Password errati")';
												echo '</script>';
												die("");
											}else{
													while($tupla=$records-> fetch_assoc()){	
														//echo $tupla["id"];
													}
													//echo "Benvenuto $username";
													header('Location: homeLogin.php');
											}
									/////////////////////////////continua perchè ho messo die nel controllo == 0////////////////////////////
									if($ricordami=="ricorda"){
										//salvo
										//echo "ok ti ricordo";
										$_SESSION["username"]=$username;
										$_SESSION["password"]=$password;
									}else{
										//elimino mettendo una data di scadenza veccha
										unset($_SESSION['username']);
										unset($_SESSION['password']);
										//echo "ok non ti ricordo";
										header("Refresh:2");
									}
								
							}
						}
					}
					
						
		?>
	</body>
</body>